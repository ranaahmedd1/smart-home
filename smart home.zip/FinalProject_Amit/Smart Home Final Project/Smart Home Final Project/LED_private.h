#ifndef _HAL_LED_PRIVATE_H_
#define _HAL_LED_PRIVATE_H_

#endif

#ifndef MOTOR_DIRVER_CONFIG_H_
#define MOTOR_DIRVER_CONFIG_H_

#define  ENA_PORT        GPIOB   
#define  ENB_PORT		 GPIOD
#define  IN1_PORT        GPIOB
#define  IN2_PORT		 GPIOB
#define  IN3_PORT        GPIOB
#define  IN4_PORT        GPIOB
#define  ENB			 PIN7
#define  ENA             PIN3
#define  IN1             PIN7
#define  IN2             PIN6
#define  IN3             PIN5
#define  IN4             PIN4



#endif
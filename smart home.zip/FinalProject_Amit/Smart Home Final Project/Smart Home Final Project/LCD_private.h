#ifndef _HAL_LCD_PRIVATE_H_
#define _HAL_LCD_PRIVATE_H_

// This Function Used to send enable pulse to lcd MC
static void LCD_vidSendEnPulse();

#endif
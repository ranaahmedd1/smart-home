#ifndef _HAL_LM35_CONFIG_H_
#define _HAL_LM35_CONFIG_H_


#define ADC_Vref 2560

#endif
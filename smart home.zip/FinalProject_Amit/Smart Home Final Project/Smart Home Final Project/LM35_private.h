#ifndef _HAL_LM35_PRIVATE_H_
#define _HAL_LM35_PRIVATE_H_

#endif